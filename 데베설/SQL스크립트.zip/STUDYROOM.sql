INSERT INTO STUDYROOM (RoomID, FloorID, MaxCapacity, IsAvailable)
VALUES
(1, 1, 4, true),
(2, 1, 6, false),
(3, 1, 10, false),
(4, 2, 4, true),
(5, 2, 6, true),
(6, 2, 10, false),
(7, 3, 4, true),
(8, 3, 6, false),
(9, 3, 10, false);