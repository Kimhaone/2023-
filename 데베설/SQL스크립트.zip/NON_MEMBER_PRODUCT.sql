INSERT INTO NON_MEMBER_PRODUCT (NonMemberProductID, NonMemberProductTime, NonMemberProductPrice)
VALUES
(1, '02:00:00', 6000),   
(2, '04:00:00', 8000),  
(3, '06:00:00', 10000),  
(4, '12:00:00', 12000),  
(5, '01:00:00', 4000);