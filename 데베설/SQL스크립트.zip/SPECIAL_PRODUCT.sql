INSERT INTO SPECIAL_PRODUCT (SP_ProductID, SP_ProductTime, SP_ProductPrice)
VALUES 
(1, '02:00:00', 3000),   
(2, '04:00:00', 5000),  
(3, '06:00:00', 7000),  
(4, '12:00:00', 9000);