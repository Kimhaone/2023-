INSERT INTO SEAT_RES (UserID, SeatID, ReservationStartTime, CheckoutTime)
VALUES (1, 1,'2023-11-23 14:00:00', '2023-11-23 16:00:00');
INSERT INTO SEAT_RES (UserID, SeatID, ReservationStartTime, CheckoutTime)
VALUES (2, 2,'2023-11-23 16:00:00', '2023-11-23 18:00:00');
INSERT INTO SEAT_RES (UserID, SeatID, ReservationStartTime, CheckoutTime)
VALUES (3, 4,'2023-11-23 10:00:00', '2023-11-23 16:00:00');
INSERT INTO SEAT_RES (UserID, SeatID, ReservationStartTime, CheckoutTime)
VALUES (4, 5,'2023-11-23 09:00:00', '2023-11-23 15:00:00');
INSERT INTO SEAT_RES (UserID, SeatID, ReservationStartTime, CheckoutTime)
VALUES (5, 8,'2023-11-23 08:00:00', '2023-11-23 16:00:00');
INSERT INTO SEAT_RES (UserID, SeatID, ReservationStartTime, CheckoutTime)
VALUES (6, 10,'2023-11-24 15:00:00', NULL);
INSERT INTO SEAT_RES (UserID, SeatID, ReservationStartTime, CheckoutTime)
VALUES (7, 11,'2023-11-24 16:00:00', NULL);
INSERT INTO SEAT_RES (UserID, SeatID, ReservationStartTime, CheckoutTime)
VALUES (8, 13,'2023-11-24 16:00:00', NULL);
INSERT INTO SEAT_RES (UserID, SeatID, ReservationStartTime, CheckoutTime)
VALUES (9, 15,'2023-11-24 18:00:00', NULL);
INSERT INTO SEAT_RES (UserID, SeatID, ReservationStartTime, CheckoutTime)
VALUES (10, 16,'2023-11-24 20:00:00', NULL);
INSERT INTO SEAT_RES (UserID, SeatID, ReservationStartTime, CheckoutTime)
VALUES (101, 18,'2023-11-23 14:00:00', '2023-11-23 16:00:00');
INSERT INTO SEAT_RES (UserID, SeatID, ReservationStartTime, CheckoutTime)
VALUES (102, 19,'2023-11-23 17:00:00', '2023-11-23 19:00:00');
INSERT INTO SEAT_RES (UserID, SeatID, ReservationStartTime, CheckoutTime)
VALUES (103, 21,'2023-11-24 14:00:00', NULL);
INSERT INTO SEAT_RES (UserID, SeatID, ReservationStartTime, CheckoutTime)
VALUES (104, 22,'2023-11-24 15:00:00', NULL);
INSERT INTO SEAT_RES (UserID, SeatID, ReservationStartTime, CheckoutTime)
VALUES (105, 23,'2023-11-24 16:00:00', NULL);
INSERT INTO SEAT_RES (UserID, SeatID, ReservationStartTime, CheckoutTime)
VALUES (106, 24,'2023-11-24 17:00:00', NULL);
INSERT INTO SEAT_RES (UserID, SeatID, ReservationStartTime, CheckoutTime)
VALUES (107, 25,'2023-11-24 18:00:00', NULL);
INSERT INTO SEAT_RES (UserID, SeatID, ReservationStartTime, CheckoutTime)
VALUES (108, 27,'2023-11-24 19:00:00', NULL);
INSERT INTO SEAT_RES (UserID, SeatID, ReservationStartTime, CheckoutTime)
VALUES (109, 29,'2023-11-24 20:00:00', NULL);
INSERT INTO SEAT_RES (UserID, SeatID, ReservationStartTime, CheckoutTime)
VALUES (110, 30,'2023-11-24 21:00:00', NULL);